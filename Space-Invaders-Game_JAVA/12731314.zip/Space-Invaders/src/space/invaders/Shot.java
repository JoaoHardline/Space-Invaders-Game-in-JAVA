package space.invaders;

/**
 * @author joaopedro
 * @deprecated Classe que sera implementada os metodos para o tiro da nave
 * para a primeira parte, nao se fez necessaria a implementacao dos metodos do tiro
 */

public class Shot extends Character{

    
    
    Shot(int x, int y, int vida, char simbolo){
        super(x, y, vida, simbolo);
    }
    
    @Override
    public void mover(int sentido){
        
    }
    
    
}
